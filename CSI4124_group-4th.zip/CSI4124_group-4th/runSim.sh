#!/usr/bin/env bash
#Single and multiqueue simulations v1.0

localPath="YOUR_LOCAL_PATH_/CSI4124_group-4th"

jarName="CSI4124_group-4th.jar"


#arguments
meanDivider=1
maxQueueSize=5
maxTrial=5
resultLevel=4

echo "Starting Simultations"

time=$(date +"%T")
echo "Results stored in file: results_$time"
file="./results_$time"
if ((resultLevel > 4)); then
    file="./results_$time.csv"
fi
cd "$localPath" && java -jar "$jarName" $meanDivider $maxQueueSize $maxTrial $resultLevel >"$file"
echo
timeend=$(date +"%T")
echo "Simulation completed $timeend"
difference=$(($(date -d "$timeend" "+%s") - $(date -d "$time" "+%s")))

echo "Execution time = $difference seconds"

echo
echo "Displaying output from results_$time"
echo
less -R "$file"
